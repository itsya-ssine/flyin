"""
Pathfinding for the Fly-in drone routing simulation.

Ported from the reference fly-in implementation. Rather than computing a
single shortest path, this module enumerates every simple route from the
start zone to the end zone, computes each route's total cost, and keeps
*all* routes that share the minimal cost. Handing the simulation engine
this whole pool of equally-good routes (instead of just one, or a handful
picked by a k-shortest-paths heuristic) is what lets large drone fleets
spread out and clear bottleneck maps in very few turns.
"""
from __future__ import annotations
from models import Graph, Zone


def build_cost_graph(graph: Graph) -> dict[str, list[tuple[Zone, int]]]:
    """
    Build an adjacency list keyed by zone name, with per-edge turn costs.

    Faithful to the reference algorithm, the cost of traversing a
    connection is always taken from the zone type of the connection's
    second endpoint (``zone_b``, i.e. whichever zone was written second in
    the map file) -- the same cost is used for both directions of travel.
    This is a quirk of the original implementation, preserved here so the
    two engines select the same minimal-cost routes.

    Args:
        graph: The parsed drone network graph.

    Returns:
        Mapping of zone name to a list of (neighbor_zone, cost) tuples.
    """
    adjacency: dict[str, list[tuple[Zone, int]]] = {}
    for conn in graph.connections:
        cost = conn.zone_b.zone_type.cost()
        adjacency.setdefault(conn.zone_a.name, []).append((conn.zone_b, cost))
        adjacency.setdefault(conn.zone_b.name, []).append((conn.zone_a, cost))
    return adjacency


def find_all_minimal_cost_paths(
    graph: Graph,
    start: Zone,
    end: Zone,
) -> list[list[Zone]]:
    """
    Enumerate every simple path from start to end and keep the cheapest ones.

    Uses a DFS-style stack search: every simple path (no zone visited
    twice) is explored, its total cost accumulated edge by edge, and only
    the paths tied for the minimum total cost are returned. Edges whose
    cost would be -1 (i.e. entering a blocked zone) are never followed.

    Args:
        graph: The drone network graph.
        start: Starting zone.
        end: Destination zone.

    Returns:
        List of minimal-cost paths, each a list of zones from start to end.

    Raises:
        ValueError: If no path exists from start to end.
    """
    adjacency = build_cost_graph(graph)
    stack: list[tuple[list[Zone], int]] = [([start], 0)]
    found: list[tuple[int, list[Zone]]] = []

    while stack:
        path, cost_so_far = stack.pop()
        current = path[-1]

        if current == end:
            found.append((cost_so_far, path))
            continue

        for neighbor, cost in adjacency.get(current.name, []):
            if cost == -1:
                continue  # blocked zone -- never traversable
            if neighbor in path:
                continue  # keep paths simple (no revisits)
            stack.append((path + [neighbor], cost_so_far + cost))

    if not found:
        raise ValueError("No path found from start to end.")

    best_cost = min(cost for cost, _ in found)
    return [path for cost, path in found if cost == best_cost]
