"""
Simulation engine for the Fly-in drone routing system.

Ported from the reference fly-in implementation. The path-finding step
(`pathfinder.find_all_minimal_cost_paths`) produces a *shared pool* of
every minimal-cost route from start to end -- drones are not pre-assigned
to one of them. Instead, every turn, each drone re-scans that shared pool
in order and advances along the first route that offers an available next
hop, claiming a zone/link capacity slot as it goes. Restricted zones are
entered as a two-turn "half move": a drone first occupies the connecting
link for one turn, then completes the move into the zone on the next.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
from models import Graph, Zone, ZoneType, Connection, DroneState
from pathfinder import find_all_minimal_cost_paths


@dataclass
class TurnRecord:
    """Records drone movements in a single simulation turn."""
    turn_number: int
    movements: list[tuple[str, str]] = field(default_factory=list)
    # (drone_name, destination_label)

    def add_movement(self, drone_name: str, dest_label: str) -> None:
        """Record a drone movement."""
        self.movements.append((drone_name, dest_label))

    def format_output(self) -> str:
        """Format this turn's movements in the required output format."""
        if not self.movements:
            return ""
        parts = [f"{dn}-{dl}" for dn, dl in sorted(self.movements)]
        return " ".join(parts)


class SimulationEngine:
    """
    Core simulation engine.

    Computes the shared minimal-cost path pool once, then advances drones
    turn by turn: each drone scans the pool for the first route offering a
    free next hop, claims it if both the destination zone and the
    connecting link have spare capacity, and otherwise waits for the next
    turn. Drones are processed in id order each turn, and capacity
    counters are updated immediately as each drone's move is decided, so
    earlier drones in a turn effectively get first pick of contested slots.
    """

    def __init__(self, graph: Graph) -> None:
        """
        Initialize the simulation engine.

        Args:
            graph: The parsed drone network graph.
        """
        self.graph = graph
        self.drones: list[DroneState] = []
        self.paths: list[list[Zone]] = []
        self.turn_records: list[TurnRecord] = []

    def setup(self) -> None:
        """Compute the shared path pool and place drones at the start zone."""
        assert self.graph.start_zone is not None
        assert self.graph.end_zone is not None

        start = self.graph.start_zone
        end = self.graph.end_zone

        # Reset runtime capacity counters in case this graph is re-run.
        for zone in self.graph.zones.values():
            zone.occupancy = 0
            zone.incoming = 0
        for conn in self.graph.connections:
            conn.passing = 0

        try:
            self.paths = find_all_minimal_cost_paths(self.graph, start, end)
        except ValueError as e:
            raise RuntimeError(str(e)) from e

        # Drones start parked at the start zone (no capacity slot is
        # claimed for this initial placement, matching the reference
        # implementation -- only zones entered via a move consume one).
        self.drones = [
            DroneState(drone_id=i + 1, current_zone=start)
            for i in range(self.graph.nb_drones)
        ]

    def run(self) -> list[TurnRecord]:
        """
        Run the full simulation until all drones arrive.

        Returns:
            List of TurnRecords, one per simulation turn.
        """
        self.setup()
        max_turns = 10000  # safety limit

        for turn_num in range(1, max_turns + 1):
            record = TurnRecord(turn_number=turn_num)
            self._execute_turn(record)
            if record.movements:
                self.turn_records.append(record)

            if all(d.arrived for d in self.drones):
                break

        return self.turn_records

    def _next_hop(self, current_zone: Zone) -> Optional[Zone]:
        """
        Find the next zone a drone should move to this turn.

        Scans the shared minimal-cost path pool in order; for the first
        path that contains the given zone, checks whether that path's
        next zone currently has capacity. Returns the first such zone
        found, or None if no path offers an available move right now.

        Args:
            current_zone: The zone the drone currently occupies.

        Returns:
            The next Zone to move into, or None if the drone should wait.
        """
        for path in self.paths:
            try:
                idx = path.index(current_zone)
            except ValueError:
                continue
            next_zone = path[idx + 1]
            if not next_zone.can_enter():
                continue
            return next_zone
        return None

    def _execute_turn(self, record: TurnRecord) -> None:
        """
        Advance every drone by at most one step for this turn.

        Drones in transit across a restricted-zone link always complete
        their move (the slot was already reserved when they started).
        Drones sitting in a zone look for an available next hop and move
        if both the destination zone and the connecting link have room.

        Args:
            record: TurnRecord to fill with this turn's movements.
        """
        assert self.graph.end_zone is not None
        end_zone = self.graph.end_zone

        for drone in self.drones:
            if drone.arrived:
                continue

            if drone.in_transit is not None:
                self._complete_transit(drone, record, end_zone)
                continue

            assert drone.current_zone is not None
            next_zone = self._next_hop(drone.current_zone)
            if next_zone is None:
                continue

            conn = self.graph.get_connection(drone.current_zone, next_zone)
            if conn is None or not conn.can_pass():
                continue

            self._move(drone, next_zone, conn, record, end_zone)

    def _complete_transit(
        self, drone: DroneState, record: TurnRecord, end_zone: Zone
    ) -> None:
        """
        Finish a drone's traversal of a restricted-zone link.

        Args:
            drone: The drone completing its half-move.
            record: TurnRecord to fill with this turn's movements.
            end_zone: The graph's end zone (to detect arrival).
        """
        assert drone.in_transit is not None
        conn, dest_zone = drone.in_transit

        dest_zone.incoming -= 1
        conn.leave_station()
        drone.current_zone = dest_zone
        drone.in_transit = None
        if dest_zone == end_zone:
            drone.arrived = True

        record.add_movement(drone.drone_name, dest_zone.name)

    def _move(
        self,
        drone: DroneState,
        next_zone: Zone,
        conn: Connection,
        record: TurnRecord,
        end_zone: Zone,
    ) -> None:
        """
        Move a drone one hop along its chosen route.

        Restricted destination zones are entered as a two-turn half move:
        the drone occupies the link this turn and arrives next turn.
        Every other zone type is entered immediately.

        Args:
            drone: The drone being moved.
            next_zone: The destination zone for this hop.
            conn: The connection being used.
            record: TurnRecord to fill with this turn's movements.
            end_zone: The graph's end zone (to detect arrival).
        """
        assert drone.current_zone is not None

        if next_zone.zone_type == ZoneType.RESTRICTED:
            next_zone.incoming += 1
            drone.current_zone.leave_station()
            drone.current_zone = None
            drone.in_transit = (conn, next_zone)
            conn.enter_station()
            record.add_movement(
                drone.drone_name, f"{conn.zone_a.name}-{conn.zone_b.name}"
            )
        else:
            drone.current_zone.leave_station()
            drone.current_zone = next_zone
            next_zone.enter_station()
            if next_zone == end_zone:
                drone.arrived = True
            record.add_movement(drone.drone_name, next_zone.name)


def simulate(graph: Graph) -> tuple[list[TurnRecord], list[DroneState]]:
    """
    Run a complete drone routing simulation.

    Args:
        graph: The parsed drone network graph.

    Returns:
        Tuple of (turn_records, final_drone_states).
    """
    engine = SimulationEngine(graph)
    records = engine.run()
    return records, engine.drones
