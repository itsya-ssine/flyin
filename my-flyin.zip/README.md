# Fly-in: Drone Routing Simulation

*This project has been created as part of the 42 curriculum.*

## Description

Fly-in is a drone routing simulation system that navigates a fleet of drones through a
network of connected zones from a start hub to an end hub. The goal is to route all
drones in the **fewest possible simulation turns** while respecting capacity, zone type,
and movement constraints.

### Key features

- Exhaustive minimal-cost path enumeration (no external graph libraries)
- A shared pool of equally-good routes that drones claim dynamically, turn by turn
- Zone types: `normal`, `restricted` (two-turn half move), `priority` (free to enter), `blocked`
- Per-zone and per-connection capacity constraints
- Turn-by-turn conflict resolution and deadlock avoidance
- Colored terminal output showing drone movements and zone states

## Instructions

### Install dependencies

```bash
make install
# or manually:
pip install flake8 mypy
```

### Run simulation

```bash
# Default example map
make run

# Custom map
make run MAP=maps/easy_linear.txt

# Raw output only (machine-readable format)
python main.py maps/example.txt --raw
```

### Lint

```bash
make lint         # flake8 + mypy standard
make lint-strict  # mypy --strict
```

### Clean

```bash
make clean
```

## Algorithm Design

### Pathfinding

Ported from the reference **fly-in** implementation. Instead of computing a single
shortest path, `pathfinder.find_all_minimal_cost_paths` does an exhaustive DFS-style
search that enumerates **every simple route** from start to end, sums each route's
turn cost, and keeps **all** routes tied for the minimum cost:

- `normal` → 1 turn
- `priority` → 0 turns (free to enter)
- `restricted` → 2 turns
- `blocked` → never traversable

Handing the simulation engine the *whole pool* of equally-good routes (rather than
one path, or a handful chosen by a heuristic) is what lets a large drone fleet spread
out and clear heavily-bottlenecked maps in very few turns.

### Turn-by-turn movement

Drones are **not** pre-assigned to a fixed route. Each turn, every drone (processed
in id order) re-scans the shared path pool for the first route offering an available
next hop, and claims it if both the destination zone and the connecting link have
spare capacity:

1. Drones mid-transit through a restricted-zone link always complete their move
   first (the capacity slot was already reserved when they set off).
2. Drones sitting in a zone scan the path pool in order for the first reachable,
   not-yet-full next zone.
3. Capacity counters are updated immediately as each drone's move is decided, so
   drones earlier in the turn's processing order get first claim on contested slots.
4. A drone that finds no available move simply waits and retries next turn.

### Restricted zones

Entering a `restricted` zone is a two-turn "half move": the drone occupies the
connecting link for one turn, then completes the move into the zone on the next.
This is reflected directly in the turn output as a `Dn-zoneA-zoneB` movement
(occupying the link) followed by a `Dn-zoneB` movement (arriving) on the next line.

## Visual Representation

The colored terminal output uses ANSI escape codes:

| Color | Meaning |
|-------|---------|
| Bright green | Start zone |
| Bright yellow | End zone |
| Yellow | Restricted zone |
| Green | Priority zone |
| Red | Blocked zone |
| Cyan | Normal zone |
| Per-drone colors | Individual drone movements |

Turn-by-turn output shows each drone's movement, making it easy to trace paths and
identify bottlenecks.

## Resources

- Depth-first search: https://en.wikipedia.org/wiki/Depth-first_search
- ANSI escape codes: https://en.wikipedia.org/wiki/ANSI_escape_code
- Python type hints: https://docs.python.org/3/library/typing.html
- PEP 257 Docstrings: https://peps.python.org/pep-0257/

### AI usage

Claude (Anthropic) was used to assist with:
- Structuring the project into OOP modules
- Writing docstrings and type hints
- Reviewing edge cases in the parser
- Porting the path-finding and turn-scheduling algorithm from a reference
  fly-in implementation into this project's existing module layout
- Drafting this README

All code was reviewed, understood, and tested before use.
